function setup() {
  createCanvas(400, 500);
  frameRate(30);
}

let xPlayer = [0, 0, 0, 0];
let yPlayer = [75, 150, 225, 300];
let Player = ["😎", "❤️", "👽", "🏎️"];
let Keys = ["1", "2", "3", "4"];

let auto = false;

function draw() {
  activeGame();
  drawPlayers();
  drawFinishLine();
  checkWinner();
  
  if (auto) {
    movePlayersAutomatically();
  }
}

function activeGame() {
  if (focused) {
    background("green");
  } else {
    background("red");
  }
}

function drawPlayers() {
  textSize(40);
  for (let i = 0; i < Player.length; i++) {
    text(Player[i], xPlayer[i], yPlayer[i]);
  }
}

function drawFinishLine() {
  fill("white");
  rect(350, 0, 10, 500);
  fill("black");
  for (let actualY = 0; actualY < 500; actualY += 20) {
    rect(350, actualY, 10, 10);
  }
}

function checkWinner() {
  for (let i = 0; i < Player.length; i++) {
    if (xPlayer[i] > 350) {
      text(Player[i] + " venceu!", 50, 200);
      noLoop();
      setTimeout(resetGame, 2000);
    }
  }
}

function resetGame() {
  xPlayer = [0, 0, 0, 0, 0];
  loop();
}

function keyReleased() {
  for (let i = 0; i < Player.length; i++) {
    if (!auto && key === Keys[i]) {
      xPlayer[i] += random(20);
    }
  }
}

function movePlayersAutomatically() {
  for (let i = 0; i < Player.length; i++) {
    if (focused) {
         xPlayer[i] += random(1, 5); 
    }
  }
}